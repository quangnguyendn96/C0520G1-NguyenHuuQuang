package finalCourse.commons;

public class CheckCodeExist extends Exception{
    public CheckCodeExist(String s){
        super(s);
    }

}
